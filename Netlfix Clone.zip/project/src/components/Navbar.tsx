import React, { useState, useEffect } from 'react';
import { Bell, Search, ChevronDown } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-colors duration-300 ${isScrolled ? 'bg-zinc-900' : 'bg-transparent'}`}>
      <div className="px-4 md:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <h1 className="text-red-600 text-3xl font-bold">NETFLIX</h1>
          <div className="hidden md:flex items-center gap-6">
            <a href="#" className="text-sm hover:text-gray-300">Home</a>
            <a href="#" className="text-sm hover:text-gray-300">TV Shows</a>
            <a href="#" className="text-sm hover:text-gray-300">Movies</a>
            <a href="#" className="text-sm hover:text-gray-300">New & Popular</a>
            <a href="#" className="text-sm hover:text-gray-300">My List</a>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <button className="p-2 hover:text-gray-300">
            <Search size={20} />
          </button>
          <button className="p-2 hover:text-gray-300">
            <Bell size={20} />
          </button>
          <div className="flex items-center gap-2 cursor-pointer">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=50&h=50&fit=crop"
              alt="Profile"
              className="w-8 h-8 rounded"
            />
            <ChevronDown size={16} />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;