import React from 'react';

interface MovieRowProps {
  title: string;
  category: string;
}

const MovieRow: React.FC<MovieRowProps> = ({ title, category }) => {
  // In a real app, these would come from an API
  const movies = Array(6).fill(null).map((_, i) => ({
    id: i,
    title: `Movie ${i + 1}`,
    image: `https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=300&h=450&fit=crop`
  }));

  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {movies.map((movie) => (
          <div key={movie.id} className="relative group">
            <img
              src={movie.image}
              alt={movie.title}
              className="w-full aspect-[2/3] object-cover rounded-md transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center rounded-md">
              <span className="text-white text-sm">{movie.title}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MovieRow;